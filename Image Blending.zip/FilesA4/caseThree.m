img5 = imread('case3/inp1.JPG');
img6 = imread('case3/inp2.JPG');
img5_size = size(img5);
img6_size = size(img6);
gray1 = rgb2gray(img5);
gray2 = rgb2gray(img6);

bin1 = im2bw(gray1);
bin2 = im2bw(gray2);
case3 = xor(bin1, bin2);
imshow(output);
subplot(2,3,1); imshow(img5); title('Input5');
subplot(2,3,2); imshow(img6); title('Input6');
subplot(2,3,3); imshow(case3); title('Output');

