img1 = imread('case1/inp1.JPG');
img2 = imread('case1/inp2.JPG');

img1_size = size(img1);
img2_size = size(img2);

% Compute the number of columns to extract from each image
half_cols = img1_size(2)/2;
% Extract the left half of the columns from the first image
img1_left = img1(:, 1:half_cols, :);
% Extract the right half of the columns from the second image
img2_right = img2(:, (img2_size(2)-half_cols+1):end, :);
% Concatenate the two images
case1 = horzcat(img1_left, img2_right);
%Binary image
gray1 = rgb2gray(img1);
gray2 = rgb2gray(img2);
bin1 = im2bw(gray1);
bin2 = im2bw(gray2);
case1_bin = xor(bin1, bin2);

subplot(2,4,1); imshow(img1); title('Input 1');
subplot(2,4,2); imshow(img2); title('Input2');
subplot(2,4,3); imshow(case1); title('Combined Colored Img Output');
subplot(2,4,4); imshow(case1_bin); title('Combined Binary Img Output');
