img3 = imread('case2/inp1.JPG');
img4 = imread('case2/inp2.JPG');
img3_size = size(img3);
img4_size = size(img4);
half_cols = floor(img4_size(1)/2);
img3_left = img4(:, 1:half_cols, :);
img4_right = img3(:, (img3_size(1)-half_cols+1):end, :);
% Define the size of the Gaussian filter
%filter_size = 7;
%filter_sigma = 4;
% Create the Gaussian filter
%filter = fspecial('gaussian', filter_size, filter_sigma);
gray3 = rgb2gray(img3);
gray4 = rgb2gray(img4);
half_cols = floor(img4_size(1)/2);
img3_left = img4(:, 1:half_cols, :);
img4_right = img3(:, (img3_size(1)-half_cols+1):end, :);
case2 = horzcat(img3_left, img4_right);
%smooth_img = imgaussfilt(case2, 5);

%Binary image
gray1 = rgb2gray(img3);
gray2 = rgb2gray(img4);
bin1 = im2bw(gray1);
bin2 = im2bw(gray2);
case2_bin = xor(bin1, bin2);

subplot(2,4,1); imshow(img3); title('Input3');
subplot(2,4,2); imshow(img4); title('Input4');
subplot(2,4,3); imshow(case2); title('Combined Colored Img Output');
subplot(2,4,4); imshow(case2_bin); title('Combined Binary Img Output');
% Apply the filter to the image
%smoothed_img = imfilter(case2, filter, 'replicate');
%imshow(smoothed_img);



