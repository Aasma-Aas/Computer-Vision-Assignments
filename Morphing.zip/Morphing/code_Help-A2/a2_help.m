
close all;
im1 = imread('Ileft.ppm');

figure
    imshow(im1);
    
% for i=1:240
%     for j=1:320
%         im1(i,j,2) =0; % blue
%         im1(i,j,3) =0; % green
%         
%     end
% end

im1(:,:,2) = 0;   %blue to zero
im1(:,:,3) = 0;   %green to zero

figure 
    imshow(im1);
    
% im2 = imread('Iright.ppm');
% figure
%     imshow(im2);
%     
% im3 = imread('Iambient.ppm');   
% figure
%     imshow(im3);