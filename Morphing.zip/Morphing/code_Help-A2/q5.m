% Read input images
Ia = imread('Ileft.ppm');
Ib = imread('Iright.ppm');

% Define the number of intermediate images to generate
num_images = 11;

% Generate sequence of images with intermediate lighting
for i = 0:num_images-1
    w = i/(num_images-1);
    morphing = uint8(w*Ia + (1-w)*Ib);
    imwrite(morphing, sprintf('morphing%02d.ppm', i+1));
end