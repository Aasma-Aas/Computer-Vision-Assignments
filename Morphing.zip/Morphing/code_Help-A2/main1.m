%Name: Syed Farooq Ali
%Purpose: To introduce basic of matlab
%Date: Feb 11, 2017

%--------------------------------------------------------------------------
close all;                      %close already opened windows
%% 1) Reads and writes an ima

im1 = imread('owl.pgm');        %reads an image
%shows the image
figure
    imshow(im1);     
imwrite(im1,'owl_Out.pgm');      %writes the image

%% 2) Copy im1 to im2_50 and add 50 to each pixel of im2_50 using for loop.
%displays and saves the image


%add 50 to the image using for loop
im2_50 = im1;                   %copy im1 matrix to im2_50

%add 50 to each pixel using for loop
for i=1:size(im1,1)             %size(im1,1) gives rows of the image
    for j=1:size(im1,2)         %size(im1,2) gives cols of the image
        im2_50(i,j) = im2_50(i,j) +50;
    end
end

%view the image
figure
imshow(im2_50);
imwrite(im2_50, 'owl_50-For-Out2.pgm', 'pgm');
%% 3) Copy im1 to im3_50 and add 50 to each pixel without using for loop.

im3_50 = im1;
im3_50 = im3_50 + 50;       %adds 50 to each pixel of image

imwrite(im3_50, 'owl_50-Out3.pgm', 'pgm');


1