% Read the left image
Ileft = imread('Ileft.ppm');

% Convert the left image to grayscale
Ileft_gray = rgb2gray(Ileft);

% Write the grayscale image to file
imwrite(Ileft_gray, 'Ileft_Gray.pgm', 'pgm');

imshow(Ileft_gray)

% Read the right image
Iright = imread('Iright.ppm');

% Convert the right image to grayscale
Iright_gray = rgb2gray(Iright);

% Write the grayscale image to file
imwrite(Iright_gray, 'Iright_Gray.pgm', 'pgm');
imshow(Iright_gray)
