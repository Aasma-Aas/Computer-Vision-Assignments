% Read the ambient image
Iambient = imread('Iambient.ppm');

% Read the left image
Ileft = imread('Ileft.ppm');

% Find the contribution of the left lamp by subtracting the ambient from the left image
Ileft_contribution = Ileft - Iambient;

% Display the left image and its contribution from the left lamp side-by-side
figure;
subplot(1,2,1);
imshow(Ileft);
title('Left Image');
subplot(1,2,2);
imshow(Ileft_contribution);
title('Left Lamp Contribution');

% Read the right image
Iright = imread('Iright.ppm');

% Find the contribution of the right lamp by subtracting the ambient from the right image
Iright_contribution = Iright - Iambient;

% Display the right image and its contribution from the right lamp side-by-side
figure;
subplot(1,2,1);
imshow(Iright);
title('Right Image');
subplot(1,2,2);
imshow(Iright_contribution);
title('Right Lamp Contribution');
