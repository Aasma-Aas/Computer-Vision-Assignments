% Read the input image
I = imread('Ileft.ppm');
R = imread('Iright.ppm');
% Set the green and blue layers to zero
% Set the RED layer to zero for Ileft.ppm
I_Red = I;
I_Red(:,:,2:3) = 0;
% Set the RED layer to zero for Iright.ppm
R_Red = I;
R_Red(:,:,2:3) = 0;
% Set the GREEN layer to zero for Ileft.ppm
I_Green = I;
I_Green(:,:,1) = 0;
I_Green(:,:,3) = 0;
% Set the GREEN layer to zero for Iright.ppm
R_Green = I;
R_Green(:,:,1) = 0;
R_Green(:,:,3) = 0;
% Set the BLUE layer to zero for Ileft.ppm and
I_Blue = I;
I_Blue(:,:,1:2) = 0;
% Set the BLUE layer to zero for Iright.ppm
R_Blue = I;
R_Blue(:,:,1:2) = 0;
% Save the Iright.ppm output images
imwrite(I_Red, 'Ileft_Red.ppm');
imwrite(I_Green, 'Ileft_Green.ppm');
imwrite(I_Blue, 'Ileft_Blue.ppm');
% Save the  Iright.ppm output images
imwrite(R_Red, 'Iright_Red.ppm');
imwrite(R_Green, 'Iright_Green.ppm');
imwrite(R_Blue, 'Iright_Blue.ppm');
figure
    imshow(I_Red)
figure
    imshow(I_Green)
figure
    imshow(I_Blue)
% right img
figure
    imshow(R_Red)
figure
    imshow(R_Green)
figure
    imshow(R_Blue)