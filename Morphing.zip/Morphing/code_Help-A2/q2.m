% Read the left image
Ileft = imread('Ileft.ppm');

% Subtract 255 from each pixel to generate the negative
Ileft_neg = 255 - Ileft;

% Display the original and negative images side-by-side
figure;
subplot(1,2,1);
imshow(Ileft);
title('Original Image');
subplot(1,2,2);
imshow(Ileft_neg);
title('Ileft Negative Image');

% Read the right image
Iright = imread('Iright.ppm');

% Subtract 255 from each pixel to generate the negative
Iright_neg = 255 - Iright;

% Display the original and negative images side-by-side
figure;
subplot(1,2,1);
imshow(Iright);
title('Original Image');
subplot(1,2,2);
imshow(Iright_neg);
title('Iright Negative Image');
